from django.contrib import admin
from deck.models import User, Deck

admin.site.register(User)
admin.site.register(Deck)
